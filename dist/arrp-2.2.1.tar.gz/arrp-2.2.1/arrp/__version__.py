"""Current version of package."""
__version__ = "2.2.1"