from .input import build_input

__all__ = ["build_input"]