"""Current version of package arrp"""
__version__ = "2.4.0"