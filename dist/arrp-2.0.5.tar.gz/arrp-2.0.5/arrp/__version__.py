"""Current version of package."""
__version__ = "2.0.5"